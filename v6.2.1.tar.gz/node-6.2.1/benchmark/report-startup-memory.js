'use strict';
console.log(process.memoryUsage().rss);
