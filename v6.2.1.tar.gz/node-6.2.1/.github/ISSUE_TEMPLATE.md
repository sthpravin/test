<!--
Thank you for reporting an issue. Please fill in the template below. If unsure
about something, just do as best as you're able.

Version: usually output of `node -v`
Platform: either `uname -a` output, or if Windows, version and 32 or 64-bit
Subsystem: if known, please specify affected core module name

If possible, please provide code that demonstrates the problem, keeping it as
simple and free of external dependencies as you are able.
-->

* **Version**:
* **Platform**:
* **Subsystem**:

<!-- Enter your issue details below this comment. -->
